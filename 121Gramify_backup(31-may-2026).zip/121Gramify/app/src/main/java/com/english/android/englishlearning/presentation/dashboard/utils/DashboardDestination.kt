package com.english.android.englishlearning.presentation.dashboard.utils

import androidx.annotation.DrawableRes

import com.english.android.englishlearning.R

sealed class DashboardDestination(
    val route: String,
    val label: String,
    @DrawableRes val iconRes: Int
) {

    object HomeScreen : DashboardDestination(
        route = "dashboard_home",
        label = "Home",
        iconRes = R.drawable.home_24px
    )

    object Article : DashboardDestination(
        route = "article",
        label = "Articles",
        iconRes = R.drawable.article_24px
    )

    object Plan : DashboardDestination(
        route = "plan",
        label = "Plan",
        iconRes = R.drawable.add_shopping_cart_24px
    )

    object Profile : DashboardDestination(
        route = "profile",
        label = "Profile",
        iconRes = R.drawable.account_circle_24px
    )

    object SpeakingPlatform : DashboardDestination(
        route = "speaking_platform",
        label = "Speaking",
        iconRes = R.drawable.account_circle_24px
    )


    companion object {
        val items = listOf(HomeScreen, Article, Plan, Profile)
    }
}
