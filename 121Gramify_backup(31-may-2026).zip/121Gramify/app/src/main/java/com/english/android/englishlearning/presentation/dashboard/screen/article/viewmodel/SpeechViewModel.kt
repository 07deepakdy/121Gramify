package com.english.android.englishlearning.presentation.dashboard.screen.article.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.english.android.englishlearning.domain.model.SpeechResult
import com.english.android.englishlearning.domain.usecase.ObserveSpeechResultUseCase
import com.english.android.englishlearning.domain.usecase.StartListeningUseCase
import com.english.android.englishlearning.domain.usecase.StopListeningUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SpeechViewModel(
    private val startListening: StartListeningUseCase,
    private val stopListening: StopListeningUseCase,
    private val observeSpeech: ObserveSpeechResultUseCase
) : ViewModel(){

    private val _transcript = MutableStateFlow<List<String>>(emptyList())
    val transcript = _transcript.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording  = _isRecording.asStateFlow()

    private var lastPartial: String? = null

    init {
        viewModelScope.launch {
            observeSpeech().collect { result ->
                when (result) {

                    is SpeechResult.Partial -> {
                        lastPartial = result.text

                        _transcript.update { list ->
                            if (list.isEmpty()) {
                                listOf(result.text)
                            } else {
                                list.dropLast(1) + result.text
                            }
                        }
                    }

                    is SpeechResult.Final -> {
                        lastPartial = null

                        _transcript.update { list ->
                            if (list.isEmpty()) {
                                listOf(result.text)
                            } else {
                                list + result.text
                            }
                        }
                    }

                    is SpeechResult.Error -> {
                        _isRecording.value = false
                    }
                }
            }
        }
    }



    fun onMicClick() {
        if (_isRecording.value) {
            stopListening()
        } else {
            startListening()
        }
        _isRecording.value = !_isRecording.value
    }

}