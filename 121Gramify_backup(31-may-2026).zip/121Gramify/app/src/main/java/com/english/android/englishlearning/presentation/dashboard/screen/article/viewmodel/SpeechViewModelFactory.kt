package com.english.android.englishlearning.presentation.dashboard.screen.article.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.english.android.englishlearning.domain.usecase.ObserveSpeechResultUseCase
import com.english.android.englishlearning.domain.usecase.StartListeningUseCase
import com.english.android.englishlearning.domain.usecase.StopListeningUseCase

class SpeechViewModelFactory(
    private val startListening: StartListeningUseCase,
    private val stopListening: StopListeningUseCase,
    private val observeSpeech: ObserveSpeechResultUseCase
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SpeechViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SpeechViewModel(
                startListening,
                stopListening,
                observeSpeech
            ) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
