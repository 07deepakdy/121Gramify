package com.english.android.englishlearning.presentation.dashboard.screen.home


import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done

import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.english.android.englishlearning.R
import com.english.android.englishlearning.presentation.dashboard.screen.home.ui.HomeCardItem
import com.english.android.englishlearning.presentation.dashboard.screen.home.ui.HomeUiState
import com.english.android.englishlearning.ui.theme.AppTheme

@Composable
fun HomeScreen(
    state: HomeUiState,
    onChipClick: (String) -> Unit,
    onCardClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        /* -------- Chips Section (FULL WIDTH) -------- */
        item(span = { GridItemSpan(maxLineSpan) }) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                state.chipItems.forEach { chip ->
                    AssistChipExample(
                        text = chip,
                        selected = state.selectedChips.contains(chip),
                        onClick = { onChipClick(chip) }
                    )
                }
            }
        }

        /* -------- Divider -------- */
        item(span = { GridItemSpan(maxLineSpan) }) {
            HorizontalDivider(thickness = 2.dp)
        }

        /* -------- Today -------- */
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                text = "Today",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        /* -------- Daily Dose Card (FULL WIDTH) -------- */
        item(span = { GridItemSpan(maxLineSpan) }) {
            DailyDoseCard(
                title = "Daily Dose",
                questionCount = 15,
                durationMinutes = 20,
                onClick = { /* navigate */ }
            )
        }

        /* -------- Practice -------- */
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text(
                text = "Practice",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        /* -------- GRID ITEMS -------- */
        items(state.cardItems) { item ->
            ElevatedCardExample(
                title = item.title,
                imageRes = item.icon,
                onClick = {
                    onCardClick(item.title)
                }
            )
        }

    }



}


@Composable
fun DailyDoseCard(
    title: String = "Daily Dose",
    questionCount: Int = 15,
    durationMinutes: Int = 20,
    onClick: () -> Unit = {}
) {
    ElevatedCard(
        onClick = onClick,
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        elevation = CardDefaults.elevatedCardElevation(
            defaultElevation = 6.dp
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {

            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "$questionCount questions",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "$durationMinutes minutes",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )

        }
    }
}


@Composable
fun ElevatedCardExample(
    title: String,
    imageRes: Int,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {

            Image(
                painter = painterResource(id = imageRes),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                modifier = Modifier.padding(horizontal = 12.dp),
                style = MaterialTheme.typography.titleSmall,
                textAlign = TextAlign.Center
            )
        }
    }
}


@Composable
fun AssistChipExample(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(text)
        },
        leadingIcon = if (selected) {
            {
                Icon(
                    imageVector = Icons.Filled.Done,
                    contentDescription = "Selected",
                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                )
            }
        } else {
            null
        }
    )
}



@Preview(
    name = "Home Screen – Light",
    showBackground = true,
    device = Devices.PIXEL_7
)
@Composable
fun HomeScreenPreview() {

    val previewState = HomeUiState(
        chipItems = listOf(
            "Grammar",
            "Vocabulary",
            "Speaking",
            "Listening",
            "Writing"
        ),
        selectedChips = setOf("Grammar"),
        cardItems = listOf(
            HomeCardItem("Listening", R.drawable.daily_practice),
            HomeCardItem("Speaking", R.drawable.speak),
            HomeCardItem("Writing", R.drawable.book),
            HomeCardItem("Mock Exam", R.drawable.cal)
        ),
        isLoading = false,
        errorMessage = null
    )

    AppTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            HomeScreen(
                state = previewState,
                onChipClick = {},
                onCardClick = {},
                modifier = Modifier
            )
        }
    }
}



