package com.english.android.englishlearning.presentation.dashboard.screen.article


import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.english.android.englishlearning.data.recognizer.AndroidSpeechRecognizerDataSource
import com.english.android.englishlearning.data.repository.SpeechRepositoryImpl
import com.english.android.englishlearning.domain.usecase.ObserveSpeechResultUseCase
import com.english.android.englishlearning.domain.usecase.StartListeningUseCase
import com.english.android.englishlearning.domain.usecase.StopListeningUseCase
import com.english.android.englishlearning.presentation.dashboard.screen.article.viewmodel.SpeechViewModel
import com.english.android.englishlearning.presentation.dashboard.screen.article.viewmodel.SpeechViewModelFactory
import com.english.android.englishlearning.ui.theme.AppTheme

@Composable
fun ArticleScreen() {

    val context = LocalContext.current
    val activity = context as Activity

    // ---- Mic permission state ----
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            hasMicPermission = granted
        }

    // ---- Permission UI ----
    if (!hasMicPermission) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {

                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(64.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Microphone permission required")

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        micPermissionLauncher.launch(
                            Manifest.permission.RECORD_AUDIO
                        )
                    }
                ) {
                    Text("Enable Microphone")
                }
            }
        }
        return
    }

    // ----- Data layer -----
    val dataSource = remember {
        AndroidSpeechRecognizerDataSource(context.applicationContext)
    }

    val repository = remember {
        SpeechRepositoryImpl(dataSource)
    }

    // ----- Domain layer -----
    val startListening = remember { StartListeningUseCase(repository) }
    val stopListening = remember { StopListeningUseCase(repository) }
    val observeSpeech = remember { ObserveSpeechResultUseCase(repository) }

    val factory = remember {
        SpeechViewModelFactory(
            startListening,
            stopListening,
            observeSpeech
        )
    }

    val viewModel: SpeechViewModel = viewModel(factory = factory)

    val transcript by viewModel.transcript.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()

    LiveSpeechRecorderScreen(
        transcript = transcript,
        isRecording = isRecording,
        onMicClick = viewModel::onMicClick
    )
}



@Composable
fun LiveSpeechRecorderScreen(
    transcript: List<String>,
    isRecording: Boolean,
    onMicClick: () -> Unit
) {
    val listState = rememberLazyListState()

    // ✅ Auto-scroll when new transcript arrives
    LaunchedEffect(transcript.size) {
        println("DEBUG_UI: transcript size = ${transcript.size}")
        if (transcript.isNotEmpty()) {
            listState.animateScrollToItem(transcript.lastIndex)
            println("DEBUG_UI: scrolling to index ${transcript.lastIndex}")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {

        // --------- Live Transcription ----------
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(bottom = 120.dp)
                .background(Color(0xFFEFEFEF)), // 🔍 DEBUG visual
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(transcript) { index, line ->
                Text(
                    text = "${index + 1}. $line",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.Black
                )
            }
        }

        // --------- DEBUG INFO ----------
        Text(
            text = "Lines: ${transcript.size}",
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            color = Color.Red,
            style = MaterialTheme.typography.labelMedium
        )


        // --------- Recorder Button ----------
        FloatingActionButton(
            onClick = onMicClick,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(72.dp),
            containerColor =
                if (isRecording)
                    MaterialTheme.colorScheme.error
                else
                    MaterialTheme.colorScheme.primary
        ) {
            Icon(
                imageVector =
                    if (isRecording) Icons.Default.Refresh
                    else Icons.Default.PlayArrow,
                contentDescription =
                    if (isRecording) "Stop Recording" else "Start Recording",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(32.dp)
            )
        }

    }
}



@Preview(
    name = "Article",
    showBackground = true,
    device = Devices.PIXEL_7
)
@Composable
fun ArticleScreenPreview(){
    AppTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            ArticleScreen()
        }
    }
}


