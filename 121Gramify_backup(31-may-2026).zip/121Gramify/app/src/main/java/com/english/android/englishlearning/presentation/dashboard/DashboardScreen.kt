package com.english.android.englishlearning.presentation.dashboard


import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MediumTopAppBar
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState

import androidx.navigation.compose.rememberNavController
import com.english.android.englishlearning.presentation.dashboard.screen.article.ArticleScreen
import com.english.android.englishlearning.presentation.dashboard.screen.home.ui.HomeRoute
import com.english.android.englishlearning.presentation.dashboard.utils.DashboardDestination
import com.english.android.englishlearning.presentation.dashboard.screen.plan.PlanScreen
import com.english.android.englishlearning.presentation.dashboard.screen.profile.ProfileScreen
import com.english.android.englishlearning.presentation.speaking.SpeakingPlatformScreen
import com.english.android.englishlearning.ui.theme.AppTheme


@Composable
fun DashboardScreen() {

    val dashboardNavController = rememberNavController()
    // Observe navigation state
    val backStackEntry by dashboardNavController.currentBackStackEntryAsState()
    val currentRoute by remember {
        derivedStateOf {
            backStackEntry?.destination?.route
        }
    }


    Scaffold(
        topBar = {
            DashboardTopBar( userName = "Deepak",notificationCount = 3, onNotificationClick = {}) },
        bottomBar = {
            BottomNavigationBar(
                navController = dashboardNavController,
                currentRoute = currentRoute
            )
        }
    ) { paddingValues ->

        DashboardNavHost(
            navController = dashboardNavController,
            modifier = Modifier.padding(paddingValues)
        )

    }
}


@Composable
fun DashboardNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = DashboardDestination.HomeScreen.route,
        modifier = modifier
    ) {

        composable(DashboardDestination.HomeScreen.route) {
            HomeRoute(
                navController = navController
            )
        }



       /* composable(DashboardDestination.SpeakingPlatform.route) {
            SpeakingPlatformScreen(
                onBack = { navController.popBackStack() }
            )
        }*/

        composable(DashboardDestination.Article.route) {
            ArticleScreen()
        }

        composable(DashboardDestination.Plan.route) {
            PlanScreen()
        }

        composable(DashboardDestination.Profile.route) {
            ProfileScreen()
        }
    }
}




@Composable
fun BottomNavigationBar(
    navController: NavHostController,
    currentRoute: String?
) {
    NavigationBar {
        DashboardDestination.items.forEach { destination ->
            NavigationBarItem(
                selected = currentRoute == destination.route,
                onClick = {
                    navController.navigate(destination.route) {
                        launchSingleTop = true
                        restoreState = true
                        popUpTo(navController.graph.startDestinationId) {
                            saveState = true
                        }
                    }
                },
                icon = {
                    Icon(
                        painter = painterResource(id = destination.iconRes),
                        contentDescription = destination.label
                    )
                },
                label = {
                    Text(destination.label)
                }
            )
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardTopBar(
    userName: String,
    notificationCount: Int,
    onNotificationClick: () -> Unit
) {
    MediumTopAppBar(
        /*colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            titleContentColor = MaterialTheme.colorScheme.primary
        ),*/
        title = {
            Column {
                Text(
                    text = "Hello $userName",
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "Let’s learn English with AI Assistant",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        },
        actions = {
            IconButton(onClick = onNotificationClick) {
                BadgedBox(
                    badge = {
                        if (notificationCount > 0) {
                            Badge {
                                Text(notificationCount.toString())
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Notifications,
                        contentDescription = "Notifications"
                    )
                }
            }
        }
    )
}






@Preview(
    name = "Dashboard – Light",
    showBackground = true,
    device = Devices.PIXEL_7
)
@Composable
fun DashboardScreenPreview() {
    AppTheme {
        // 1. Create a NavController specifically for the Preview
        val previewNavController = rememberNavController()

        // 2. Define a static route for the preview state
        val currentRoute = "home"
        Surface(modifier = Modifier.fillMaxSize()) {
            DashboardScaffold(
                topBar = { DashboardTopBar("Deepak",
                    notificationCount = 5,
                    onNotificationClick = {}) },
                bottomBar = {

                    BottomNavigationBar(
                        navController = previewNavController,
                        currentRoute = currentRoute
                    )
                }
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Preview Content")
                }
            }
        }
    }
}

@Composable
private fun DashboardScaffold(
    topBar: @Composable () -> Unit,
    bottomBar: @Composable () -> Unit,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = topBar,
        bottomBar = bottomBar,
        content = content
    )
}



